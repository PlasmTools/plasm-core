/** @generated catalog_cgs_hash=aee3d865ff02b2ac8f0c168915a63dfe8f57c87f00fab3e03c87fcec72f5eb84 entry_id=execute_tiny generated_at=2026-06-26T18:30:11.766Z */
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  createCatalogClient,
  buildDottedArgs,
  executeRows,
  plasmBoolean,
  plasmLiteral,
  plasmNumber,
  type StubInvokeOptions,
} from "@plasm_lang/vercel-agent";

export const catalogCgsHash = "aee3d865ff02b2ac8f0c168915a63dfe8f57c87f00fab3e03c87fcec72f5eb84";
export const entryId = "execute_tiny";

const catalogRoot = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "../../catalogs/execute_tiny",
);

const stubEntities = ["Category","Product"] as const;

const builder = createCatalogClient({
  entryId,
  cgsHash: catalogCgsHash,
  catalogRoot,
  stubEntities: [...stubEntities],
});

type Brand<B extends string, T> = T & { readonly __brand: B };
export type CategoryId = Brand<"CategoryId", string>;
export type RefCategory = CategoryId;
export type ProductId = Brand<"ProductId", string>;
export type RefProduct = ProductId;

export type Category = {
  id: string;
  name?: string;
};

export type Product = {
  id: string;
  name?: string;
  category_id?: string;
};

export type CategoryGetInput = {
  id: RefCategory;
};

export type ProductGetInput = {
  id: RefProduct;
};

export type ProductSearchInput = {
  q: string;
};

/** category_get */
export async function category_get(input: CategoryGetInput, options?: StubInvokeOptions): Promise<Category> {
  const program = `e1(${plasmLiteral(input.id)})`;
  const result = await executeRows<Category>(builder, program, options);
  const row = result.rows[0];
  if (!row) throw new Error("category_get: empty result");
  return row;
}

/** product_get */
export async function product_get(input: ProductGetInput, options?: StubInvokeOptions): Promise<Product> {
  const program = `e2(${plasmLiteral(input.id)})`;
  const result = await executeRows<Product>(builder, program, options);
  const row = result.rows[0];
  if (!row) throw new Error("product_get: empty result");
  return row;
}

/** product_list */
export async function product_list(options?: StubInvokeOptions): Promise<Product[]> {
  const program = "e2";
  const result = await executeRows<Product>(builder, program, options);
  return result.rows;
}

/** product_search */
export async function product_search(input: ProductSearchInput, options?: StubInvokeOptions): Promise<Product[]> {
  const program = `e2~${plasmLiteral(input.q)}`;
  const result = await executeRows<Product>(builder, program, options);
  return result.rows;
}

export const execute_tiny = {
  Category: {
      category_get,
    },
  Product: {
      product_get,
      product_list,
      product_search,
    },
  builder,
  catalogCgsHash,
  entryId,
} as const;

export default execute_tiny;
